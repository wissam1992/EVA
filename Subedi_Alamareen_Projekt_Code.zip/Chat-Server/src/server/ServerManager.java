package server;

import java.util.Scanner;
/*
* Haupt ServerManager welche für Laufen des Programms aufgerufen wird.
*
* */
public class ServerManager {
    public static void main(String[] args) {
        //Port Eingabe
        Scanner scan = new Scanner(System.in);
        System.out.println("PORT: ");
        int port = scan.nextInt();
        //neue Server wird erstellt
        Server server = new Server(port);
        //server Thread wird gestarted
        server.start();
        if (server.isAlive()){
            System.out.println("--------------ChatServer 1.0--------------");
            System.out.println("duerchgefuehrt von Ujwal Subedi & Wissam Alamareen");
            System.out.println("unter Aufsicht : Prof. Dr. Manuel Duque-Anton");
            System.out.println("Availiable : "+port);
            System.out.println("------------------------------------------");
        }
    }
}
