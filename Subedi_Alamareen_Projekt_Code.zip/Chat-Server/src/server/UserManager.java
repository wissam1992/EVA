package server;

import java.util.HashSet;

public class UserManager {

    private static UserManager instance;

    private final HashSet<User> users = new HashSet<>();
    private final HashSet<User> loggedInUsers = new HashSet<>();

    private UserManager() {
        users.add(new User("user", "password"));
        users.add(new User("usr", "pass"));
        users.add(new User("user1", "pass"));
    }

    public static UserManager getInstance() {
        if (instance == null) {
            instance = new UserManager();
        }
        return instance;
    }

    public void add(User user){
        this.users.add(user);
    }
    public void addLoggedInUser(User user){
        this.loggedInUsers.add(user);
    }

    public void removeOnlineUsers(User user){
        this.loggedInUsers.remove(user);
    }
    public HashSet<User> getUsers() {
        return users;
    }

    public HashSet<User> getLoggedInUsers() {
        return loggedInUsers;
    }
}
