package server;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * Haupt ChatServer welche jede Client Nachricht bearbeitet.
 */
public class ChatServer implements Runnable {

    private Server server;

    private Socket mSocket;

    private String username;

    private OutputStream outputStream;

    private HashSet<String> lobbies = new HashSet<>();
    //    private HashSet<User> users = new HashSet<>();
    private UserManager userManager = UserManager.getInstance();
    private List<ChatServer> workerList;

    private User currentUser = null;

    public ChatServer(Server server, Socket socket) throws IOException {
        this.server = server;
        this.mSocket = socket;
    }

    @Override
    public void run() {
        try {
            processClient();
        } catch (SocketException e) {
            System.out.println(e.getLocalizedMessage());
        } catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        } catch (InterruptedException e) {
            System.out.println(e.getLocalizedMessage());
        }
    }

    /**
     * Alle Nachrichte
     *
     * @throws IOException
     * @throws InterruptedException
     */
    private void processClient() throws IOException, InterruptedException {
        InputStream inputStream = mSocket.getInputStream();
        this.outputStream = mSocket.getOutputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        System.out.println(server.getChatServers());

        String line;
        while ((line = reader.readLine()) != null) {
            String[] tokens = StringUtils.split(line);
            System.out.println(Arrays.toString(tokens));
            if (tokens != null && tokens.length > 0) {
                String cmd = tokens[0];
                if ("logoff".equals(cmd) || "quit".equalsIgnoreCase(cmd)) {
                    this.username = tokens[1];
                    processLogoff();
                    break;
                } else if ("login".equalsIgnoreCase(cmd)) {
                    String username = tokens[1];
                    String password = tokens[2];
                    processLogin(username, password);
                } else if ("msg".equalsIgnoreCase(cmd)) {
                    String[] message = StringUtils.split(line, null, 3);
                    processMessage(message);
                } else if ("join".equalsIgnoreCase(cmd)) {
                    joinLobby(tokens);
                    allLobbies();
                } else if ("onlineUsers".equalsIgnoreCase(cmd)) {
                    getOnlineUsers("online");
//                    handleLeave(tokens);
                } else if ("leave".equalsIgnoreCase(cmd)) {
                    leaveLobby(tokens);
                } else if ("lobbies".equalsIgnoreCase(cmd)) {
                    allLobbies();
                } else if ("register".equalsIgnoreCase(cmd)) {
                    String username = tokens[1];
                    String password = tokens[2];
                    registeruser(username, password);
                } else if ("ping".equalsIgnoreCase(cmd)) {
                    outputStream.write("ok".getBytes());
                } else {
                    String msg = "unknown " + cmd + "\n";
                    outputStream.write(msg.getBytes());
                }
            }
        }
        mSocket.close();
    }

    /**
     * Es wird auf existierte Benutzer überprüft und neue Benutzer angelegt.
     *
     * @param username
     * @param password
     * @throws IOException
     */
    private void registeruser(String username, String password) throws IOException {
//        if (userManager.getUsers().contains(new User(username,password)))
        currentUser = new User("", "");
        for (User user : userManager.getUsers()) {
            if (user.getUsername().equals(username)) {
                this.currentUser = user;
            }
        }

        //Es wird nach existierte benuzter überprueft
        if (!userManager.getUsers().contains(currentUser)) {
            this.userManager.add(new User(username, password));
            System.out.println(currentUser.getUsername() + " created.");
            outputStream.write("success".getBytes());
            closeConnection();
        } else if (userManager.getUsers().contains(currentUser)) {
            userExist();
        } else {
            if (currentUser.getUsername().equals(username)) {
                userExist();
            }
            System.out.println("Registration Failed!");
            outputStream.write("failed".getBytes());
            closeConnection();
        }
    }

    /**
     * Eine Nachricht "exist" wird zu den Client geschickt.
     *
     * @throws IOException
     */
    private void userExist() throws IOException {
        outputStream.write("exist".getBytes());
        System.out.println(currentUser.getUsername() + " already exists.");
        closeConnection();
    }

    private void closeConnection() throws IOException {
        server.removeChatServer(this);
        mSocket.close();
    }

    private void allLobbies() {
        for (String lobby : lobbies) {
            sendOnlineInfo("aval " + lobby);
        }
    }

    private void leaveLobby(String[] tokens) {
        if (tokens.length > 1) {
            String topic = tokens[1];
            lobbies.remove(topic);
        }
    }

    private void joinLobby(String[] tokens) {
        if (tokens.length > 1) {
            String topic = tokens[1];
            lobbies.add(topic);
        }
    }

    private void processMessage(String[] message) {
        String sendTo = message[1];
        String body = message[2];

        boolean isTopic = sendTo.charAt(0) == '#';

        List<ChatServer> workerList = server.getChatServers();
        for (ChatServer chatServer : workerList) {
            if (isTopic) {
                if (chatServer.isMemberOfTopic(sendTo)) {
                    String outMsg = "msg " + sendTo + ":" + username + " " + body + "\n";
                    chatServer.sendMessageToClient(outMsg);
                }
            } else {
                if (sendTo.equalsIgnoreCase(chatServer.getUsername())) {
                    String outMsg = "msg " + username + " " + body + "\n";
                    chatServer.sendMessageToClient(outMsg);
                }
            }
        }
    }

    private boolean isMemberOfTopic(String lobby) {
        return lobbies.contains(lobby);
    }

    private void processLogoff() throws IOException {
        for (User user : userManager.getUsers()) {
            if (user.getUsername().equals(username)) {
                currentUser = user;
                userManager.removeOnlineUsers(currentUser);
                sendOnlineInfo("offline");
                getOnlineUsers("offline");
            }
        }
        closeConnection();
    }

    //ueberprueft ob eingegebene Benutzer in der Hashset drin gibts
    private void processLogin(String username, String password) throws IOException {
        boolean check = false;
        User loggedIn = null;
        for (User user : userManager.getUsers()) {
            if (user.check(username, password)) {
                loggedIn = user;
                check = true;
            }
        }
        if (check) {
            this.username = username;
            this.currentUser = loggedIn;
            String msg1 = "success\n";
            System.out.println(msg1);

            //Es wird eingeloggte nach benuzter überprueft
            if (!userManager.getLoggedInUsers().contains(currentUser)) {
                userManager.addLoggedInUser(currentUser);
                System.out.println(currentUser.getUsername() + " online.");
                outputStream.write(msg1.getBytes());
                sendOnlineInfo("online");
//                getOnlineUsers("online");
            } else {
                sendMessageToClient("loggedIn");
                System.out.println(currentUser.getUsername() + " already LoggedIn.");
                closeConnection();
            }
        } else {
            String msg1 = "failed\n";
            System.out.println(msg1);
            outputStream.write(msg1.getBytes());
        }
    }

    //anderen Online-Benutzern den aktuellen Status des Benutzers senden
    private void sendOnlineInfo(String message) {

        workerList = server.getChatServers();
//        getOnlineUsers();
        String onlineMsg = message + " " + this.username + "\n";
        for (ChatServer chat : workerList) {
            if (!this.username.equals(chat.getUsername())) {
                chat.sendMessageToClient(onlineMsg);
            }
        }
    }

    // aktuellen Benutzer alle anderen Online-Anmeldungen senden
    private void getOnlineUsers(String message) throws IOException {
        workerList = server.getChatServers();
        for (ChatServer chat : workerList) {
            if (chat.getUsername() != null) {
                if (!this.username.equals(chat.getUsername())) {
                    String onlineMsg = message + " " + chat.getUsername() + "\n";
                    sendMessageToClient(onlineMsg);
                }
            }
        }
    }

    //Parameter msg wird zu Client geschickt
    private void sendMessageToClient(String msg) {
        if (username != null) {
            try {
                outputStream.write(msg.getBytes());
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ChatServer{");
        sb.append("server=").append(server);
        sb.append(", lobbies=").append(lobbies);
        sb.append(", users=").append(userManager.getUsers());
        sb.append('}');
        return sb.toString();
    }

}