package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
/**
* Haupt Server Thread, welche nur einmal erstellt wird
* @version 1.0
* */
public class Server extends Thread {

    private final int port;

    private LinkedList<ChatServer> chatServers = new LinkedList<>();
//    private Map<> user und thread
    private ExecutorService clientProcessorService = new ThreadPoolExecutor(10, 25, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
    private Socket mSocket;

    //Constructor mit port
    public Server(int port) {
        this.port = port;
    }

    @Override
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            // abwarten von Client Connection
            while (true) {
                mSocket = serverSocket.accept();
                System.out.println("Connection : " + mSocket);
                //Ein neuen Thread ChatServer wird erstellt, welche alle Client Informationen bearbeitet.
                ChatServer chatServer = new ChatServer(this, mSocket);
                chatServers.add(chatServer);
                // ChatServer Thread wird weiter zu Thread Pool Executor gegeben
                clientProcessorService.submit(chatServer);
                System.out.println("Anzahl Clients: " + chatServers.size());
                Iterator<User> iterator = UserManager.getInstance().getLoggedInUsers().iterator();
                AtomicReference<String> onlineUsers = new AtomicReference<>("");
                //Liste von OnlineUsers wird auf der Console angezeigt
                iterator.forEachRemaining((element) -> {
                    onlineUsers.set(element.getUsername());
                });
                System.out.println("Online Users : "+onlineUsers.toString());

            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * gibt Liste von verbundene server.ChatServer zurück
     */
    public LinkedList<ChatServer> getChatServers() {
        return chatServers;
    }

    /**
     * die Server , die in der Liste drin sind , werden entfernt
     * @param chatServer
     */
    public void removeChatServer(ChatServer chatServer) {
        chatServers.remove(chatServer);
    }
}
