import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import ui.UIReourceEntity;

import java.io.IOException;

public class RootFile implements UIReourceEntity {
    private String name;
    public RootFile(String name){
        this.name = name;
    }

    public RootFile(){}

    public Parent getRoot(String fname) throws IOException {
        return FXMLLoader.load(getClass().getResource("ui/resources/" + fname + ".fxml"));
    }
}
