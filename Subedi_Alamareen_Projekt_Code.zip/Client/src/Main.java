import chat.Client;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage){
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("ui/resources/login.fxml"));
            primaryStage.setTitle("Hello Chat");
            primaryStage.setScene(new Scene(root, 500, 500));
        } catch (IOException | NullPointerException e) {
            System.out.println("Could not load file"+e.getMessage());
        }
        primaryStage.show();

    }


    public static void main(String[] args) {

        launch(args);

    }
}
