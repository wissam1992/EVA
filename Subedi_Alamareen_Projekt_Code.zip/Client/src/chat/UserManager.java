package chat;

import chat.blueprints.UserStatus;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import ui.controller.observer.EventSource;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * UserManager ist eine Singleton Klasse welche alle Laufzeit Informationen speichert.
 */
public class UserManager {
    private static UserManager userManagerInstance;
    private List<String> usersList = new ArrayList<>();
    private Client client;
    private ObservableList<String> onlineUsers = FXCollections.observableArrayList();
    private ObservableList<String> lobbyList = FXCollections.observableArrayList();
    private Set<User> users = new HashSet<>();
    private Map<String, ObservableList<String>> usersMessageMap = new HashMap<>();
    private Map<String, ObservableList<String>> lobbiesChatMap = new HashMap<>();
    //Thread
    private ExecutorService messageProcessorService = new ThreadPoolExecutor(10, 25, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
    /**
     * //Observer Design Pattern :
     */
    private EventSource eventSource;
    private EventSource displayStatus;

    /**
     * //Singleton Usermanger um Laufzeit Daten zu behandeln
     */
    private UserManager() {
        lobbyList.add("Joined Lobbies");
        onlineUsers.add("Online Users");
        eventSource = new EventSource();
        displayStatus = new EventSource();
    }

    public static UserManager getInstance() {
        if (userManagerInstance == null) {
            userManagerInstance = new UserManager();
        }
        return userManagerInstance;
    }

    /**
     * // User Online und Offline Status werden zugeschickt
     */
    public void onlineStatus() throws IOException {
        if (client != null) {
            client.addUserStatusListener(new UserStatus() {
                @Override
                public void online(String user) {
                    usersList.add(user);
                    Platform.runLater(() -> {
                        //change Listener
                        add(user);
                        onlineUsers.add(user);
                        User tmp = new User(user);
                        users.add(tmp);
                        usersMessageMap.put(user, tmp.getMessages());
                    });
                }

                @Override
                public void offline(String user) {
                    System.out.println("Offline " + user);
                    Platform.runLater(() -> {
                        onlineUsers.remove(user);
                    });
                    usersList.remove(user);
                }
            });
        }
    }

    public boolean serverStatus() {
        if (client.getSocket().isConnected())
            return true;
        return false;
    }

    /**
     * //Nachrichten von  anderen zu der eingeloggten Nuter
     */
    public void messageReciever() throws IOException{
        client.addMessageListener((from, bodyText) -> {
                    handleMessage(from, bodyText, from);
                }
        );
    }

    /**
     *
    //Nachrichten von der eingeloggten Nuter zu anderen
     * @param user
     * @param body
     */
    public void messageSender(String user, String body) {
        // Bsp #user wenn es Lobby ist
        new MessageProcessor(client).msg(user, body);
        handleMessage(user, body, client.getUsername());
    }

    /**
     *
    //Die Nachrichten werden in usermessageMap Hashmap gespeichert.
     * @param username
     * @param body
     * @param clientUser
     */
    private void handleMessage(String username, String body, String clientUser) {
        users.add(new User(username));
        for (User user : users) {
            String userID = user.getID();
            //Hier werden die Nachrichten
            if (user.getID().contains("#")) {
                System.out.println("Lobby : " + user.getID());
                String[] lobbyName = StringUtils.split(user.getID(), ":", 10);
                String[] removeHashtag = lobbyName[0].split("#");
                userID = removeHashtag[1];
                Platform.runLater(() -> {
                    if (!client.getUsername().equals(clientUser)) {
                        usersMessageMap.put(lobbyName[0], user.add(clientUser + " : " + body));
//                        displayStatus.notifyObservers(username);
                    }
                });
            }
            if (userID.equalsIgnoreCase(username)) {
                Platform.runLater(() -> {
                    usersMessageMap.put(username, user.add(clientUser + " : " + body));
                });
            }
        }
    }

    /**
     *
    //eingegebene Lobby wird beigetreten
     * @param name
     */
    public void joinLobby(String name) {
        client.sendMessageToServer("join #" + name);
        User tmp = new User("#" + name);
        tmp.add("***Everyone will see your Message!***");
        users.add(tmp);
        usersMessageMap.put("#" + name, tmp.getMessages());
        lobbyList.add(name);
    }

    public void add(String user) {
        this.onlineUsers.addListener((ListChangeListener<String>) change -> System.out.println("change" + change));
    }

    /**
     *
    //Es werden mehr Nachrichten nebenläufig bearbeitet, aus diesem Grund werden jede NachrichtProcessor in ThreadPool weiter gegeben.
     * @param runnable
     */
    public void executeMessage(Runnable runnable) {
        this.messageProcessorService.submit(runnable);
    }

    //----------------Getters und Setters----------------------------


    public ObservableList<String> getOnlineUsers() {
        return onlineUsers;
    }

    public List<String> getUsersList() {
        return usersList;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Map<String, ObservableList<String>> getUsersMessageMap() {
        return usersMessageMap;
    }

    public Set<User> getUsers() {
        return users;
    }

    /**
     *
     * @param name
     * @return User
     */
    //returns User
    public User getUser(String name) {
        if (!users.contains(new User(name))) {
            User user = new User(name);
            users.add(user);
            return user;
        }

        for (User user : users) {
            if (user.getID().equalsIgnoreCase(name)) {
                return user;
            }
        }
        return null;
    }

    public ObservableList<String> getLobbyList() {
        return lobbyList;
    }

    public Map<String, ObservableList<String>> getLobbiesChatMap() {
        return lobbiesChatMap;
    }

    public EventSource getEventSource() {
        return eventSource;
    }

    public void setEventSource(EventSource eventSource) {
        this.eventSource = eventSource;
    }

    public EventSource getDisplayStatus() {
        return displayStatus;
    }
}
