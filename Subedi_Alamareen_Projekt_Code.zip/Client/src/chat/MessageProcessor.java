package chat;

import chat.blueprints.UserMessage;
import chat.blueprints.UserStatus;

import java.io.IOException;
/**
* Nachrichten werden bearbeitet
* */
public class MessageProcessor implements Runnable {
    private Client client;

    public MessageProcessor(Client client) {
        this.client = client;
    }

    @Override
    public void run() {
        try {
            processOnlineStatus();
//            processMessage();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    private void processOnlineStatus() throws IOException {
        client.sendMessageToServer("onlineUsers");
        String line;
        while ((line = client.readServerMessage()) != null) {
            String[] tokens = StringUtils.split(line);
            if (tokens != null && tokens.length > 0) {
                String cmd = tokens[0];
                if ("online".equalsIgnoreCase(cmd)) {
                    for (UserStatus us : client.getUsersOnlineStatus()) {
                        us.online(tokens[1]);
                    }
                } else if ("offline".equalsIgnoreCase(cmd)) {
                    for (UserStatus us : client.getUsersOnlineStatus()) {
                        us.offline(tokens[1]);
                    }
                }else if ("msg".equalsIgnoreCase(cmd)) {
                    String[] tokensMsg = StringUtils.split(line, null, 3);
                    processMessageFromUser(tokensMsg);
                }else if ("aval".equalsIgnoreCase(cmd)) {
                    String[] tokensMsg = StringUtils.split(line, null, 4);
                    getAllLobbies(tokensMsg);
                }else {
                    System.out.println("Keine Nachricht von dem Server!");
                }
            }
        }
    }

    private void getAllLobbies(String[] tokensMsg) {
        String lobby = tokensMsg[1];
//        String msgBody = tokensMsg[2];
        System.out.println("Availiable : "+lobby);
    }

    private void processMessageFromUser(String[] tokensMsg) {
        String login = tokensMsg[1];
        String msgBody = tokensMsg[2];

        for (UserMessage listener : client.getMessages()) {
            listener.onMessage(login, msgBody);
            System.out.println(login + " : " + msgBody);
        }
    }

    //Nachricht wird zu den Server geschickt
    public void msg(String sendTo, String msgBody) {
        String cmd = "msg " + sendTo + " " + msgBody + "\n";
        client.sendMessageToServer(cmd);
    }
}
