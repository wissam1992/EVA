package chat.blueprints;

public interface UserMessage {
    public void onMessage(String fromUsername, String message);
}
