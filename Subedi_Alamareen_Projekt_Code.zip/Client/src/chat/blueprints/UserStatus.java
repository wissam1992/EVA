package chat.blueprints;

public interface UserStatus {
    public void online(String user);
    public void offline(String user);
}
