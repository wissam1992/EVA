package chat.blueprints;

public interface Preferences {
    //Notwendige Methode für Nachrichten und Online Status
    public void addUserStatusListener(UserStatus status);
    public void removeUserStatusListener(UserStatus status);
    public void addMessageListener(UserMessage message);
    public void removeMessageListener(UserMessage message);
}
