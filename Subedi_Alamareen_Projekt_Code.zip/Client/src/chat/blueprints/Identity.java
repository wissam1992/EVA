package chat.blueprints;

public interface Identity<T> {
     T getID();
}
