package chat;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<Client> clients = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            Client client = new Client("localhost",2222);
            clients.add(client);
        }
        System.out.println("Clients "+clients.size());
    }
}
