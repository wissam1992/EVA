package chat;

public enum Type {
    LOGIN,REGISTER;
    public enum Message{
        SUCCESS,LOGGEDIN,FAILED,EXIST;
    }
}
