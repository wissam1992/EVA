package chat;

import chat.blueprints.Identity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.Serializable;

/**
 * Alle Information von der Benutzer werden in User gespeichert, auch einzelne Lobby ist als ein User gezählt.
 * Es wird eine Entity/Object für jede Nutzer erstellt.
 */
public class User implements Identity<String>, Serializable {
    private String userID;
    //Alle Nachrichten werden hier gespeichert
    private ObservableList<String> messages = FXCollections.observableArrayList();

    public User(String userID) {
        this.userID = userID;
        //Unterschiedliche Start Nachrichten für Lobbies und Users
        if (userID.contains("#")) {
            messages.add("Say Hello to Everyone in " + userID);
        } else {
            messages.add("Chat with " + userID);
        }
    }

    @Override
    public String getID() {
        return userID;
    }

    /**
     * //Die alle Nachrichten zwischen eingeloggte User und andere Partei werden hier gespeichert.
     *
     * @param chat
     * @return
     */
    public ObservableList<String> add(String chat) {
        this.messages.add(chat);
        return messages;
    }

    public ObservableList<String> getMessages() {
        return messages;
    }

}
