package chat;

import chat.blueprints.Preferences;
import chat.blueprints.UserMessage;
import chat.blueprints.UserStatus;
import ui.controller.observer.EventSource;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Haupt Client Klasse, welche alle Client befehle handelt
 */
public class Client implements Preferences {
    private Socket socket;
    private int port;
    private String host;

    private OutputStream outputStream;
    private PrintStream printStream;

    private InputStream inputStream;
    private BufferedReader bufferedReader;

    private final ArrayList<UserStatus> usersOnlineStatus = new ArrayList<>();
    private final ArrayList<UserMessage> messages = new ArrayList<>();
    private final ArrayList<MessageProcessor> messageProcessors = new ArrayList<>();

    private String username;
    private EventSource displayStatus;

    public Client(String host, int port) {
        this.host = host;
        this.port = port;
        getSocketConnection();
        displayStatus = UserManager.getInstance().getDisplayStatus();
    }

    /**
     * //alle wichtige Initialization
     */
    public void getSocketConnection() {
        //if (socket == null)
        try {
            this.socket = new Socket(host, port);
            this.outputStream = socket.getOutputStream();
            this.printStream = new PrintStream(outputStream, true);

            this.inputStream = socket.getInputStream();
            this.bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        } catch (IOException e) {
            System.out.println("Server: " + e.getMessage());
            displayStatus.notifyObservers("Server Error: " + e.getMessage());
        }

    }

    /**
     * //SUCCESS, LOGGEDIN oder FAILED wird zurueckgegeben
     *
     * @param username
     * @param password
     * @return
     */
    public Type.Message login(String username, String password) {
        try {
            sendMessageToServer("login " + username + " " + password);
            //wir warten auf "success" Nachricht von dem Server, damit wir login bestaetigen koennen
            String message = "";
            message = bufferedReader.readLine();
            System.out.println(message);
            if ("success".equalsIgnoreCase(message)) {
                /**
                 *
                 //Wenn login erfolgreich ist, wird eine MessageProcessor erstellt und
                 // in ThreadPool von der Singleton Klasse UserManager für weiter Bearbeitung geschickt
                 */
                MessageProcessor msgProcessor = new MessageProcessor(this);
                UserManager.getInstance().executeMessage(msgProcessor);
                this.username = username;
                messageProcessors.add(msgProcessor);
                return Type.Message.SUCCESS;
            } else if ("loggedIn".equalsIgnoreCase(message)) {
                displayStatus.notifyObservers(username + " already Logged In");
                return Type.Message.LOGGEDIN;
            } else if ("failed".equalsIgnoreCase(message)) {
                displayStatus.notifyObservers(username + " login failed!");
                return Type.Message.FAILED;
            } else {
                displayStatus.notifyObservers(username + " login failed! Server Error");
                return Type.Message.FAILED;
            }
//            return false;
        } catch (IOException u) {
            displayStatus.notifyObservers("Server Error Message: " + u.getMessage());
            System.out.println(u.getMessage());
        }
        return Type.Message.FAILED;
    }

    /**
     * benutzer wird ausgeloggt
     * @param username
     * @return
     */
    public boolean logout(String username) {
        try {
            sendMessageToServer("logoff " + username);
            //wir warten auf "success" Nachricht von dem Server, damit wir login bestaetigen koennen
            String message = "";
            message = bufferedReader.readLine();
            System.out.println(message);
            if ("success".equalsIgnoreCase(message)) {
                return true;
            } else {
                return false;
            }

        } catch (IOException u) {
            System.out.println(u.getMessage());
        }
        return true;
    }

    /**
     *
    //Register Methode, welche username und password erwartet
     * @param username
     * @param password
     * @return
     */
    public Type.Message register(String username, String password) {
        try {
            sendMessageToServer("register " + username + " " + password);
            String message = "";
            message = bufferedReader.readLine();
            System.out.println(message);
            if ("success".equalsIgnoreCase(message)) {
                MessageProcessor msgProcessor = new MessageProcessor(this);
                UserManager.getInstance().executeMessage(msgProcessor);
                this.username = username;
                messageProcessors.add(msgProcessor);
                return Type.Message.SUCCESS;
            } else if ("exist".equalsIgnoreCase(message)) {
                displayStatus.notifyObservers(username + " already Exists!");
                return Type.Message.EXIST;
            } else {
                displayStatus.notifyObservers("Registration Failed!");
                return Type.Message.FAILED;
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return Type.Message.FAILED;
    }

    /**
     *
     * @param command
     * @throws NullPointerException
     */
    public void sendMessageToServer(String command) throws NullPointerException {
        this.printStream.println(command);
    }

    /**
     *
     * @return
     * @throws IOException
     */
    public String readServerMessage() throws IOException {
        return bufferedReader.readLine();
    }

    @Override
    public void addUserStatusListener(UserStatus status) {
        usersOnlineStatus.add(status);
    }

    @Override
    public void removeUserStatusListener(UserStatus status) {
        usersOnlineStatus.remove(status);
    }

    @Override
    public void addMessageListener(UserMessage message) {
        messages.add(message);
    }

    @Override
    public void removeMessageListener(UserMessage message) {
        messages.remove(message);
    }

    //Getters und Setters


    public OutputStream getOutputStream() {
        return outputStream;
    }

    public BufferedReader getBufferedReader() {
        return bufferedReader;
    }

    public ArrayList<MessageProcessor> getMessageProcessors() {
        return messageProcessors;
    }

    public ArrayList<UserStatus> getUsersOnlineStatus() {
        return usersOnlineStatus;
    }

    public ArrayList<UserMessage> getMessages() {
        return messages;
    }

    public String getUsername() {
        return username;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Socket getSocket() {
        return socket;
    }

}
