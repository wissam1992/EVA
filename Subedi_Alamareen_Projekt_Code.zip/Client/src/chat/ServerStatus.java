package chat;

import javafx.application.Platform;

import java.io.*;

public class ServerStatus implements Runnable{
    UserManager manager = UserManager.getInstance();
    Client client = manager.getClient();
    @Override
    public void run() {
        while(true){
            try {
                if (statusCheck()) break;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
            System.out.println("Server Status: Not Connected!");
            System.out.println("Closing Application ...");
            Platform.exit();
            System.exit(0);
        }
        try {
            System.out.println("End "+statusCheck());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean statusCheck() throws IOException {
        OutputStream raus = client.getSocket().getOutputStream();
        PrintStream ps = new PrintStream(raus, true);

        ps.println("ping");

        InputStream rein = client.getSocket().getInputStream();
        BufferedReader buff = new BufferedReader(new InputStreamReader(rein));
        return buff.readLine() != null;
    }
}
