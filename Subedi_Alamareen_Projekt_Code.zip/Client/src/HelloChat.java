public class HelloChat {
    public static void main(String[] args) {
        Main.main(args);
    }
}
