package ui;

import javafx.scene.Parent;

import java.io.IOException;

public interface UIReourceEntity {
    Parent getRoot(String fname) throws IOException;
}
