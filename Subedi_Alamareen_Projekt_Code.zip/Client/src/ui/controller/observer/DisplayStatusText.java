package ui.controller.observer;

public class DisplayStatusText implements EventSource.Observer {
    private String text;

    public DisplayStatusText() {
    }

    @Override
    public void update(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
