package ui.controller.observer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CurrentState implements EventSource.Observer {

    private String user;
    private ObservableList<String> list = FXCollections.observableArrayList();

    public CurrentState() {
    }

    @Override
    public void update(String user) {
        this.user = user;
        System.out.println("Current User : "+user);
    }

    public String getUser() {
        return user;
    }
}
