package ui.controller;

import chat.Client;
import chat.Type;
import chat.UserManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import ui.UIResource;
import ui.controller.observer.DisplayStatusText;
import ui.controller.observer.EventSource;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController extends UIResource implements Initializable {


    @FXML
    private Button btnLogin;
    @FXML
    private Button settings;
    @FXML
    private Button register;

    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    private Button btnLogoff;

    @FXML
    private Label error;
    private final UserManager userManager;
    private Client client;

    private String host;
    private int port;

    private EventSource msgSource;
    private DisplayStatusText displayStatus = new DisplayStatusText();

    public LoginController() {
        this.host = "localhost";
        this.port = 2222;
        try {
            client = new Client(host, port);
        } catch (NullPointerException n) {
            System.out.println("Could Not Load ");
        }
        userManager = UserManager.getInstance();
        userManager.setClient(client);
        msgSource = userManager.getDisplayStatus();
        msgSource.addObserver(displayStatus);
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {

        try {
            //client.getSocket();
            userManager.onlineStatus();
            userManager.messageReciever();
            System.out.println(userManager.getClient().getHost());
            loginProcessor(event, userManager);
        } catch (IOException e) {
            error.setText("Connection Failed! " + e.getLocalizedMessage());
        } catch (NullPointerException n) {
            error.setText("Connection Failed! " + n.getLocalizedMessage());
        }

    }

    private void loginProcessor(ActionEvent event, UserManager userManager) throws IOException, ConnectException {
        try {
            auth(event, btnLogin, userManager, Type.LOGIN);

        } catch (IOException | NullPointerException e) {
            error.setText("Connection Failed! " + e.getLocalizedMessage());
        }
    }

    @FXML
    public void configSettings(ActionEvent event) {
        if (event.getSource() == settings) {
                Dialog<String> dialog = new Dialog<>();
                dialog.setTitle("Config Setting");
                dialog.setHeaderText("Enter Host Infos \n");
                dialog.setResizable(true);
                Label label1 = new Label("Host: ");
                TextField host = new TextField();
                host.setText(this.host);
                Label label2 = new Label("Port: ");
                TextField port = new TextField();
                port.setText(String.valueOf(this.port));
                ButtonType confirm = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
                GridPane grid = new GridPane();
                grid.addRow(0, label1, host);
                grid.addRow(1, label2, port);
                grid.setHgap(30);
                dialog.getDialogPane().setContent(grid);
                dialog.getDialogPane().getButtonTypes().add(confirm);
                dialog.setResultConverter((okBtn) -> {
                    if (okBtn == confirm) {
                        this.host = host.getText();
                        this.port = Integer.parseInt(port.getText());
                        System.out.println(this.host + " : " + this.port);
                        try {
                            createNewClient();
                        } catch (IOException | NullPointerException e) {
                            error.setText("Connection Failed! " + e.getLocalizedMessage());
                        }

                    }
                    return null;
                });
                dialog.show();
        }
    }

    @FXML
    public void registerUser(ActionEvent event) throws IOException {
        try {
            auth(event, register, userManager, Type.REGISTER);

        } catch (IOException | NullPointerException e) {
            error.setText("Connection Failed! " + e.getLocalizedMessage());
        }
    }

    private void auth(ActionEvent event, Button submit, UserManager userManager, Type type) throws IOException {
        if (event.getSource() == submit) {
            String user = username.getCharacters().toString();
            String pass = password.getCharacters().toString();

            Type.Message loginMessage = userManager.getClient().login(user, pass);
            switch (type) {
                case LOGIN:
                    boolean success = loginMessage == Type.Message.SUCCESS;
                    boolean loggedIn = loginMessage == Type.Message.LOGGEDIN;
                    boolean failed = loginMessage == Type.Message.FAILED;
                    if (success) {
                        System.out.println("User login Success");
                        loadScreen(btnLogin, "homescreen");

                    } else if (loggedIn) {
                        //Die Verbindung wird abgebrochen wenn man schon angemeldet ist. Deswegen erstellen wir neue Client.
                        btnLogoff.setDisable(false);
                        createNewClient();
//                        loadScreen(btnLogin,"login");
                    } else if (failed) {
                        //Login Fehlermeldung!
                        //Es werden die Nachrichten angezeigt, die in displayStatus drin gibt's
//                       msgSource.notifyObservers("Login Failed...");
                        btnLogoff.setDisable(false);
                        createNewClient();
//                        loadScreen(btnLogin,"login");

                    }
                    break;
                case REGISTER:
                    Type.Message regCheck = userManager.getClient().register(user, pass);
                    boolean regSuccess = regCheck == Type.Message.SUCCESS;
                    boolean exist = regCheck == Type.Message.EXIST;
                    boolean regFailed = regCheck == Type.Message.FAILED;
                    if (regSuccess) {
                        System.out.println("Registration Success");
                        createNewClient();
                        registrationSuccess();
                    } else if (exist) {
                        //Register Fehlermeldung!
                        createNewClient();
                    } else if (regFailed) {
                        createNewClient();
                    }
                    break;
                default:
                    msgSource.notifyObservers("Something went Wrong!");
            }
            error.setText(displayStatus.getText());
        }
    }

    //Neue Client wird erstellt
    private void createNewClient() throws IOException, NullPointerException {
        Client client_n = new Client(host, port);
        this.client = client_n;
        userManager.setClient(client_n);
    }

    // Dieser Dialog wird angezeigt, wenn die Registrierung erfolgreich war.
    private void registrationSuccess() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Registration");
        dialog.setHeaderText("Registration Successful! \n");
        dialog.setResizable(true);
        Label label1 = new Label("Welcome to HelloChat. Please Login to Enjoy the features.");
        ButtonType confirm = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        GridPane grid = new GridPane();
        grid.addRow(0, label1);
        grid.setHgap(30);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().add(confirm);
        dialog.setResultConverter((okBtn) -> {
            if (okBtn == confirm) {
                try {
                    //ladet login fenster
                    loadScreen(register, "login");
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
            return null;
        });
        dialog.show();
    }

    //logout call von dem Login Fenster
    @FXML
    public void logout(ActionEvent event) throws IOException {
        if (event.getSource() == btnLogoff) {
            if (client.logout(username.getText())) {
                System.out.println("Logout Successful!");
            }
            loadScreen(btnLogoff, "login");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        username.setPromptText("Username ...");
        password.setPromptText("Password ...");
        btnLogoff.setDisable(true);

    }

}
