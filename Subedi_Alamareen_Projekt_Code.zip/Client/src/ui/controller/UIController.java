package ui.controller;

import javafx.scene.Parent;
import javafx.stage.Stage;

public class UIController {

    private static UIController uIControllerInstance;
    private Stage stage;
    private Parent root;

    private UIController() {
    }

    public static UIController getInstance() {
        if (uIControllerInstance == null) {
            uIControllerInstance = new UIController();
        }
        return uIControllerInstance;
    }


    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Parent getRoot() {
        return root;
    }

    public void setRoot(Parent root) {
        this.root = root;
    }
}
