package ui.controller;

import chat.Client;
import chat.ServerStatus;
import chat.UserManager;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import ui.UIResource;
import ui.controller.observer.DisplayStatusText;
import ui.controller.observer.EventSource;
import ui.controller.observer.CurrentState;

import java.io.IOException;
import java.net.URL;
import java.util.*;


public class Homescreen extends UIResource implements Initializable {

    @FXML
    private Button btnLogoff;
    @FXML
    private Button joinLobby;

    private final UserManager userManager = UserManager.getInstance();
    private final Client client = userManager.getClient();

    @FXML
    private ListView<String> usersListView;
    @FXML
    private ListView<String> lobbiesListview;
    @FXML
    private ListView<String> chatList;

    private Map<String, ObservableList<String>> usersMessageMap = new HashMap<>();
    private Map<String, ObservableList<String>> lobbyChatMap = new HashMap<>();

    @FXML
    private Label username;

    @FXML
    private TextField messageText;
    @FXML
    private Label displayMsg;

    @FXML
    private Button btnSend;

    private String selectedListItem = null;

    private EventSource eventSource;
    private EventSource displayStatus;
    private CurrentState currentState = new CurrentState();
    /**
     * Aktuelle Benachrichtung wird gespeichert.
     */
    private DisplayStatusText displayStatusText = new DisplayStatusText();

    /**
     * wichtige initialization
     *
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        usersMessageMap = userManager.getUsersMessageMap();
        lobbyChatMap = userManager.getLobbiesChatMap();
        loadOnlineUsers();
        username.setText(UserManager.getInstance().getClient().getUsername());
        loadLobbies();
        messageText.setDisable(true);
        eventSource = userManager.getEventSource();
        eventSource.addObserver(currentState);
        displayStatus = userManager.getDisplayStatus();
        displayStatus.addObserver(displayStatusText);
        displayStatus.notifyObservers("Notification message will be shown here.");
        displayMsg.setText("Info : " + displayStatusText.getText());
        //Server Status Check
        Platform.runLater(() -> {
            userManager.executeMessage(new ServerStatus());
        });
    }

    private void loadLobbies() {
        lobbiesListview.setItems(userManager.getLobbyList());

        lobbiesListview.setOnMouseClicked((mouseEvent) -> {
            selectedListItem = lobbiesListview.getSelectionModel().getSelectedItem();
            currentState.update("#" + selectedListItem);
            eventSource.notifyObservers("#" + selectedListItem);
            messageText.setDisable(false);
            if (usersMessageMap.containsKey(currentState.getUser())) {
                chatList.setItems(usersMessageMap.get(currentState.getUser()));
            }
        });
    }

    /**
     * //Ein Dialog , womit man Lobby eintreten können
     *
     * @param event
     */
    @FXML
    public void joinMyLobby(ActionEvent event) {
        if (event.getSource() == joinLobby) {
            Dialog<String> dialog = new Dialog<>();
            dialog.setTitle("Join Lobbies");
            dialog.setHeaderText("Enter Lobby Name \n");
            dialog.setResizable(true);
            Label label1 = new Label("Name: #");
            TextField lobby = new TextField();
            ButtonType confirm = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            GridPane grid = new GridPane();
            grid.add(label1, 1, 1);
            grid.add(lobby, 2, 1);
            dialog.getDialogPane().setContent(grid);
            dialog.getDialogPane().getButtonTypes().add(confirm);
            dialog.setResultConverter((okBtn) -> {
                if (okBtn == confirm) {
                    System.out.println(lobby.getText());
                    displayStatus.notifyObservers("Joined " + lobby.getText());
                    userManager.joinLobby(lobby.getText());
                    displayMsg.setText("Info: " + displayStatusText.getText());
                }
                return null;
            });

            dialog.show();
        }
    }

    private void loadOnlineUsers() {
        //users online info
        for (String user : userManager.getUsersList()) {
            System.out.println(user + " is online.");
        }
        //Alle Online Users sind in Observable List gespeichert
        ObservableList<String> list = userManager.getOnlineUsers();
        usersListView.setItems(list);
        //Wenn Nutzer eine Name von der angezeigte Online Users klickt, wird folgendes passiert
        usersListView.setOnMouseClicked(
                mouseEvent -> {
                    //enable text input after user is selected
                    messageText.setDisable(false);
                    //geklickte user
                    selectedListItem = usersListView.getSelectionModel().getSelectedItem();
                    //CurrentState wird aktualisiert, damit wir immer aktuelle User haben können
                    currentState.update(selectedListItem);
                    if (usersMessageMap.containsKey(selectedListItem)) {
                        chatList.setItems(usersMessageMap.get(selectedListItem));
                    }
                }
        );
    }

    //
    @FXML
    public void sendMessage(ActionEvent event) {
        if (event.getSource() == btnSend) {
            String text = messageText.getText();
            System.out.println("Selected : " + currentState.getUser());
            try {
                userManager.messageSender(currentState.getUser(), text);
            } catch (Exception e) {
                displayStatus.notifyObservers(e.getLocalizedMessage());
            }

            //Javafx nutzt Platform.runlater für die Bearbeiten
            Platform.runLater(() -> {
                if (currentState.getUser() != null) {
                    //Es wird ObservableList von Nachrichten geladen
                    chatList.setItems(usersMessageMap.get(currentState.getUser()));
                }
            });
            //Chat Box wird geleert
            messageText.setText("");
        }
    }

    @FXML
    public void logout(ActionEvent event) throws IOException {
        if (event.getSource() == btnLogoff) {
            if (client.logout(client.getUsername())) {
                System.out.println("Logout Successful!");
            }
            loadScreen(btnLogoff, "login");
        }
    }


}

