package ui;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ui.UIReourceEntity;
import ui.controller.UIController;
import ui.controller.observer.EventSource;

import java.io.IOException;

public abstract class UIResource{

    public void loadScreen(Button btn, String name) throws IOException {
        Parent root = null;
        Stage stage;
        stage = (Stage) btn.getScene().getWindow();

        try {
            Class<?> rootFile = Class.forName("RootFile");
            UIReourceEntity tempRoot = (UIReourceEntity) rootFile.newInstance();
            root = tempRoot.getRoot(name);

        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }

//        root = FXMLLoader.load(getClass().getResource("ui/resources/" + name + ".fxml"));
        Scene scene = new Scene(root);
        UIController.getInstance().setStage(stage);
        UIController.getInstance().setRoot(root);
        stage.setScene(scene);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                Platform.exit();
                System.exit(0);
            }
        });
        stage.show();
    }

    public void loadScreenStage(MouseEvent event, String name) throws IOException {
        Parent root;
        Stage stage = new Stage();
//        event.getScreenX();
//        if (stage != null) {
            root = FXMLLoader.load(getClass().getResource("resources/" + name + ".fxml"));
            Scene scene = new Scene(root);
            UIController.getInstance().setStage(stage);
            UIController.getInstance().setRoot(root);
            System.out.println("Stage: "+UIController.getInstance().getStage());
            stage.setScene(scene);
            stage.show();
//        } else {
//            System.out.println("Error finding Stage! "+UIController.getInstance().getStage());
//        }
    }

}
